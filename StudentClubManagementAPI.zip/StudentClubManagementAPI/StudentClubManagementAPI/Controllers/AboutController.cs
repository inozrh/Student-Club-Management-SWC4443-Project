﻿// Controllers/AboutController.cs
using Microsoft.AspNetCore.Mvc;

namespace StudentClubManagementAPI.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            // Hardcoded content for About Us page
            ViewData["Title"] = "About Us";
            ViewData["Content"] = "Welcome to the Student Club Management API. Here we manage student clubs, events, and resources.";


            return View(); // Return the view without passing a model
        }
    }
}