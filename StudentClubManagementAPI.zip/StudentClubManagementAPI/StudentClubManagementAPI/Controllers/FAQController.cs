﻿using Microsoft.AspNetCore.Mvc;
using StudentClubManagementAPI.Models;

public class FAQController : Controller
{
    public IActionResult Index()
    {
        var faqItems = new List<FAQItem>
        {
            new FAQItem
            {
                Question = "What is the process to form a new club or association at UPTM?",
                Answer = "To form a new club or association, students must submit the following items along with the application form to the unit for approval:\n" +
                         "- The constitution of the association or club\n" +
                         "- The purpose and objectives of the association or club\n" +
                         "- A plan for club activities\n" +
                         "- A list of committee members\n" +
                         "- A list of at least 30 members"
            },
            new FAQItem
            {
                Question = "Can I start a club or association on my own?",
                Answer = "No, you will need a minimum of 30 members to form a club or association at UPTM. The list of members should be included in the application."
            },
            new FAQItem
            {
                Question = "What are the benefits of joining a club or association at UPTM?",
                Answer = "Joining a club or association provides students with opportunities to engage in extracurricular activities, develop leadership skills, network with peers, and participate in various events and competitions that enhance personal and professional growth."
            },
            new FAQItem
            {
                Question = "What types of clubs and associations are currently active at UPTM?",
                Answer = "UPTM has a wide variety of active clubs and associations that cater to different interests. Some of the active clubs include:\n" +
                         "- Association of Professional Students (APROS)\n" +
                         "- Creative Media Club\n" +
                         "- Eagles Basketball Club\n" +
                         "- Extreme Youth Club\n" +
                         "- Gabungan Pelajar Melayu Semenanjung (GPMS)\n" +
                         "- Golden Scroll Society\n" +
                         "- Innovation and Creativity Exhibition Club (ICEB)\n" +
                         "- International Student Association\n" +
                         "- Kelab Accounting\n" +
                         "- Kelab Akasia\n" +
                         "- Kelab Anak Teater\n" +
                         "- Kelab Argenti\n" +
                         "- Kelab Badminton\n" +
                         "- Kelab Bola Sepak\n" +
                         "- Kelab Bowling\n" +
                         "- Kelab Catur\n" +
                         "- Kelab Cyber Security\n" +
                         "- Kelab English Language Society\n" +
                         "- Kelab E-Sport\n" +
                         "- Kelab Fasilitator\n" +
                         "- Kelab Futsal\n" +
                         "- Kelab Hoki\n" +
                         "- Kelab Kediaman\n" +
                         "- Kelab Bola Jaring (Panthera)\n" +
                         "- Kelab Ragbi\n" +
                         "- Kelab Rowing Wave Runner\n" +
                         "- Kelab Scuba Diving (Aquaphilia)\n" +
                         "- Kelab Sekretariat Rakan Muda\n" +
                         "- Kelab Sukarelawan Job Malaysia\n" +
                         "- Kelab Taekwondo WTF KPTMKL\n" +
                         "- Kelab Usahawan\n" +
                         "- Kelab Vocalism\n" +
                         "- Kelab Volleyball (White Eagles)\n" +
                         "- KUPTM Table Tennis Club (KUTEC)\n" +
                         "- Medic KUPTM\n" +
                         "- Kelab Seni Silat Gayong\n" +
                         "- Smart Caliph Society\n" +
                         "- The Magister Society\n" +
                         "- The Society of Corporate Administration (SCA)\n" +
                         "- Youth Orator Club"
            },
            new FAQItem
            {
                Question = "How do I join an existing club or association?",
                Answer = "To join an existing club or association, students should contact the respective club's committee or refer to announcements on campus or online platforms. Most clubs have membership sign-ups at the beginning of each semester or during club fairs."
            },
            new FAQItem
            {
                Question = "Can a student be a member of multiple clubs?",
                Answer = "Yes, students are allowed to join multiple clubs as long as they are able to manage their time and responsibilities effectively. Being involved in multiple clubs can provide students with a wide range of experiences."
            },
            new FAQItem
            {
                Question = "Is there any support provided for newly formed clubs?",
                Answer = "Yes, UPTM provides support for newly formed clubs, which includes approval of their constitution and club activities. Newly formed clubs may also receive funding or resources to support their operations depending on the available budget."
            },
            new FAQItem
            {
                Question = "Are there any specific requirements to be a club officer or committee member?",
                Answer = "Each club has its own set of requirements for selecting officers and committee members. Generally, students interested in taking up a leadership role must demonstrate active participation in the club and contribute to its activities. Specific requirements may vary depending on the club's constitution."
            },
            new FAQItem
            {
                Question = "How can I get more information about the active clubs?",
                Answer = "Information about active clubs can usually be obtained through the campus notice boards, the official university website, or by contacting the student affairs unit. Students can also attend club fairs or events where clubs showcase their activities."
            },
            new FAQItem
            {
                Question = "What if I want to suggest new activities for an existing club?",
                Answer = "Students who wish to suggest new activities for an existing club should approach the club’s committee. If the club committee approves, the new activities may be proposed to the university’s student affairs unit for further planning and approval."
            }
        };

        return View(faqItems);
    }
}
