﻿namespace StudentClubManagementAPI.Models
{
    public class FAQItem
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }

}
