﻿using System.ComponentModel.DataAnnotations;

namespace StudentClubManagementAPI.Models
{
    public class Club
    {
        [Key]
        public int ClubID { get; set; }

        [Required]
        [MaxLength(100)]
        public string ClubName { get; set; }

        [Required]
        [MaxLength(100)]
        public string ClubAdvisor { get; set; }


    }
}